//
//  MapViewController.swift
//  BusApp
//
//  Created by Meinhard Benedict Capucao on 11/12/19.
//  Copyright © 2019 Meinhard Benedict Capucao. All rights reserved.
//

import UIKit

class MapViewController: NSObject {

}
