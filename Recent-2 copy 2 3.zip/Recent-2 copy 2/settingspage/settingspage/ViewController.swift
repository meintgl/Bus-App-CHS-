//
//  ViewController.swift
//  settingspage
//
//  Created by Jun Chen on 11/22/19.
//  Copyright © 2019 Jun Chen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var backgroundColor: UIImageView!
    @IBOutlet weak var titleArea: UIStackView!
    
    @IBOutlet weak var profileOne: UIImageView!
    
}

