//
//  SettingsViewC.swift
//  BusAppDevelopment
//
//  Created by Meinhard Benedict Capucao on 1/9/20.
//  Copyright © 2020 Meinhard Benedict Capucao. All rights reserved.
//

import UIKit

class AccountSettings {
    var settingTitles: String?
    var settingCells: [String]?
    
  
    
    init(settingTitles: String, settingCells: [String]) {
        
        self.settingTitles = settingTitles
        self.settingCells = settingCells
        
    }
}
class SettingsViewC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var accountSettings = [AccountSettings]()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    
        accountSettings.append(AccountSettings.init(settingTitles: "Account Settings", settingCells: ["Privacy", "Terms of Use", "FAQ"]))
      
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension SettingsViewC: UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return accountSettings.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return accountSettings[section].settingCells?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        cell.textLabel?.text = accountSettings[indexPath.section].settingCells?[indexPath.row]
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return accountSettings[section].settingTitles
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 40))

        return view
     
        
        
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
}
