//
//  ViewController.swift
//  Bus
//
//  Created by Jun Chen on 11/21/19.
//  Copyright © 2019 Jun Chen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var busLocations: UIImageView!
    
    @IBAction func addBus(_ sender: UIButton) {
        
    }
 
}
