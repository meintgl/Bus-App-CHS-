//
//  MapViewController.swift
//  BusAppDevelopment
//
//  Created by Bishrut Bhattarai on 11/19/19.
//  Copyright © 2019 Meinhard Benedict Capucao. All rights reserved.
//

import UIKit
import Firebase

class MapViewController: UIViewController, UITextFieldDelegate{

    
    let userID = Auth.auth().currentUser?.uid
    
    @IBOutlet var purple: UIImageView!
    @IBOutlet var blue: UIImageView!
    @IBOutlet var green: UIImageView!
    @IBOutlet var yellow: UIImageView!
    @IBOutlet var orange: UIImageView!
    @IBOutlet var red: UIImageView!
    @IBOutlet var busStatus: UILabel!
    @IBOutlet var instructions1: UILabel!
    @IBOutlet var instructions2: UILabel!
    @IBOutlet var field1: UITextField!
    @IBOutlet var enter1: UIButton!
    @IBOutlet var busLabel1: UILabel!
    @IBOutlet var return1: UIButton!
    @IBOutlet var field2: UITextField!
    @IBOutlet var enter2: UIButton!
    @IBOutlet var busLabel2: UILabel!
    @IBOutlet var remove2: UIButton!
    @IBOutlet var field3: UITextField!
    @IBOutlet var enter3: UIButton!
    @IBOutlet var busLabel3: UILabel!
    @IBOutlet var remove3: UIButton!
    @IBOutlet var field4: UITextField!
    @IBOutlet var enter4: UIButton!
    @IBOutlet var busLabel4: UILabel!
    @IBOutlet var remove4: UIButton!
    @IBOutlet var field5: UITextField!
    @IBOutlet var enter5: UIButton!
    @IBOutlet var busLabel5: UILabel!
    @IBOutlet var remove5: UIButton!
    @IBOutlet var field6: UITextField!
    @IBOutlet var enter6: UIButton!
    @IBOutlet var busLabel6: UILabel!
    @IBOutlet var remove6: UIButton!
    var name = ""
    var busNum = 0
    var isAdmin = true
    var busLoc = 0
    var busList = [Int]()
    let ref = Database.database().reference()
    
    @IBOutlet var helloLabel: UILabel!
    @IBAction func enter1Pressed(_ sender: Any) {
        busStatus.isHidden = true
        let num = Int(field1.text ?? "0") ?? 0
        if busList.contains(num){
            let newRef = ref.child("buses").child("\(num)")
            newRef.updateChildValues(["location": "1"])
            field1.text = "Bus #"
            enter1.isHidden = true
            field1.isHidden = true
            busLabel1.text = "\(num)"
            busLabel1.isHidden = false
            return1.isHidden = false
        } else {
            busStatus.isHidden = false
            busStatus.text = "Please enter a valid bus number."
        }
    }
    
    @IBAction func enter2Pressed(_ sender: Any) {
        busStatus.isHidden = true
        let num = Int(field2.text ?? "0") ?? 0
        if busList.contains(num){
            let newRef = ref.child("buses").child("\(num)")
            newRef.updateChildValues(["location": "2"])
            field2.text = "Bus #"
            enter2.isHidden = true
            field2.isHidden = true
            busLabel2.text = "\(num)"
            busLabel2.isHidden = false
            remove2.isHidden = false
        } else {
            busStatus.isHidden = false
            busStatus.text = "Please enter a valid bus number."
        }
    }
    
    @IBAction func enter3Pressed(_ sender: Any) {
        busStatus.isHidden = true
        let num = Int(field3.text ?? "0") ?? 0
        if busList.contains(num){
            let newRef = ref.child("buses").child("\(num)")
            newRef.updateChildValues(["location": "3"])
            field3.text = "Bus #"
            enter3.isHidden = true
            field3.isHidden = true
            busLabel3.text = "\(num)"
            busLabel3.isHidden = false
            remove3.isHidden = false
        } else {
            busStatus.isHidden = false
            busStatus.text = "Please enter a valid bus number."
        }
    }
    
    @IBAction func enter4Pressed(_ sender: Any) {
        busStatus.isHidden = true
        let num = Int(field4.text ?? "0") ?? 0
        if busList.contains(num){
            let newRef = ref.child("buses").child("\(num)")
            newRef.updateChildValues(["location": "4"])
            field4.text = "Bus #"
            enter4.isHidden = true
            field4.isHidden = true
            busLabel4.text = "\(num)"
            busLabel4.isHidden = false
            remove4.isHidden = false
        } else {
            busStatus.isHidden = false
            busStatus.text = "Please enter a valid bus number."
        }
    }
    
    @IBAction func enter5Pressed(_ sender: Any) {
        busStatus.isHidden = true
        let num = Int(field5.text ?? "0") ?? 0
        if busList.contains(num){
            let newRef = ref.child("buses").child("\(num)")
            newRef.updateChildValues(["location": "5"])
            field5.text = "Bus #"
            enter5.isHidden = true
            field5.isHidden = true
            busLabel5.text = "\(num)"
            busLabel5.isHidden = false
            remove5.isHidden = false
        } else {
            busStatus.isHidden = false
            busStatus.text = "Please enter a valid bus number."
        }
    }
    
    @IBAction func enter6Pressed(_ sender: Any) {
        busStatus.isHidden = true
        let num = Int(field6.text ?? "0") ?? 0
        if busList.contains(num){
            let newRef = ref.child("buses").child("\(num)")
            newRef.updateChildValues(["location": "6"])
            field6.text = "Bus #"
            enter6.isHidden = true
            field6.isHidden = true
            busLabel6.text = "\(num)"
            busLabel6.isHidden = false
            remove6.isHidden = false
        } else {
            busStatus.isHidden = false
            busStatus.text = "Please enter a valid bus number."
        }
    }
    
    @IBAction func return1Pressed(_ sender: Any) {
        let newRef = ref.child("buses").child(busLabel1.text ?? "")
        newRef.updateChildValues(["location": "7"])
        return1.isHidden = true
        busLabel1.isHidden = true
        enter1.isHidden = false
        field1.isHidden = false
    }
    
    @IBAction func remove2Pressed(_ sender: Any) {
        let newRef = ref.child("buses").child(busLabel2.text ?? "")
        newRef.updateChildValues(["location": "7"])
        remove2.isHidden = true
        busLabel2.isHidden = true
        enter2.isHidden = false
        field2.isHidden = false
    }
    
    @IBAction func remove3Pressed(_ sender: Any) {
        let newRef = ref.child("buses").child(busLabel3.text ?? "")
        newRef.updateChildValues(["location": "7"])
        remove3.isHidden = true
        busLabel3.isHidden = true
        enter3.isHidden = false
        field3.isHidden = false
    }
    
    @IBAction func remove4Pressed(_ sender: Any) {
        let newRef = ref.child("buses").child(busLabel4.text ?? "")
        newRef.updateChildValues(["location": "7"])
        remove4.isHidden = true
        busLabel4.isHidden = true
        enter4.isHidden = false
        field4.isHidden = false
    }
    
    @IBAction func remove5Pressed(_ sender: Any) {
        let newRef = ref.child("buses").child(busLabel5.text ?? "")
        newRef.updateChildValues(["location": "7"])
        remove5.isHidden = true
        busLabel5.isHidden = true
        enter5.isHidden = false
        field5.isHidden = false
    }
    
    @IBAction func remove6Pressed(_ sender: Any) {
        let newRef = ref.child("buses").child(busLabel6.text ?? "")
        newRef.updateChildValues(["location": "7"])
        remove6.isHidden = true
        busLabel6.isHidden = true
        enter6.isHidden = false
        field6.isHidden = false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        field1.delegate = self
        field2.delegate = self
        field3.delegate = self
        field4.delegate = self
        field5.delegate = self
        field6.delegate = self
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
        userInfo()
    }
    
    func userInfo(){
        ref.child("users").child(userID!).observeSingleEvent(of: .value, with: { (snapshot) in
            let value = snapshot.value as? NSDictionary
            self.name = value?["name"] as? String ?? ""
            self.busNum = Int(value?["busNum"] as? String ?? "") ?? 0
            self.isAdmin = Bool(value?["isAdmin"] as? String ?? "") ?? true
            self.helloLabel.text = "Hello \(self.name)!"
            self.helloLabel.isHidden = false
            if !self.isAdmin{
                self.observeBus()
            } else{
                self.manageBus()
            }
        }) { (error) in
            print(error.localizedDescription)
        }
    }
    
    func manageBus(){
        instructions1.isHidden = false
        instructions2.isHidden = false
        field1.isHidden = false
        enter1.isHidden = false
        field2.isHidden = false
        enter2.isHidden = false
        field3.isHidden = false
        enter3.isHidden = false
        field4.isHidden = false
        enter4.isHidden = false
        field5.isHidden = false
        enter5.isHidden = false
        field6.isHidden = false
        enter6.isHidden = false
        let busesRef = Database.database().reference().child("buses")
        busesRef.observeSingleEvent(of: .value, with: { (snapshot) in
            for case let rest as DataSnapshot in snapshot.children {
                self.busList.append(Int(rest.key) ?? 0)            }
        })
    }
    
    
    func observeBus(){
        self.busStatus.isHidden = false
        let busRef = Database.database().reference().child("buses").child("\(self.busNum)")
        busRef.observe(.value, with: { snapshot in
            let postDict = snapshot.value as? [String: Any]
            self.busLoc = Int(postDict?["location"] as? String ?? "") ?? 0
            self.purple.isHidden = true
            self.blue.isHidden = true
            self.green.isHidden = true
            self.yellow.isHidden = true
            self.orange.isHidden = true
            self.red.isHidden = true
            switch self.busLoc{
            case 0:
                self.busStatus.text = "Your bus is on the way!"
            case 1:
                self.purple.isHidden = false
                self.busStatus.text = "Your bus is in the purple zone."
            case 2:
                self.blue.isHidden = false
                self.busStatus.text = "Your bus is in the blue zone."
            case 3:
                self.green.isHidden = false
                self.busStatus.text = "Your bus is in the green zone."
            case 4:
                self.yellow.isHidden = false
                self.busStatus.text = "Your bus is in the yellow zone."
            case 5:
                self.orange.isHidden = false
                self.busStatus.text = "Your bus is in the orange zone."
            case 6:
                self.red.isHidden = false
                self.busStatus.text = "Your bus is in the red zone."
            default:
                self.busStatus.text = "Your bus has already left."
            }
        })
    }
    
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y -= (keyboardSize.height/2)
            }
        }
    }
    
    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return false
    }


}
